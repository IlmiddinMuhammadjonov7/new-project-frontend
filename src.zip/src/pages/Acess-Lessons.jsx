import React from 'react'
import PageHeader from '../components/PageHeader'

export default function Acess_Lessons() {
  return (
    <div>
      <PageHeader title="Ro’yxatdan o’tilgan darslar" />
      <p>Bu yerda siz ro‘yxatdan o‘tgan darslaringizni ko‘rishingiz mumkin.</p>
    </div>
  )
}
