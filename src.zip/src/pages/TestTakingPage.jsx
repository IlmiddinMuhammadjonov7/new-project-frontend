import TestSubmission from "../components/TestSubmission";

export default function TestTakingPage() {
  return <TestSubmission />;
}
